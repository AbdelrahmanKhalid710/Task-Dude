﻿namespace TaskManager_
{
    partial class AddEditTaskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddEditTaskForm));
            TaskTitle = new Label();
            TaskDescription = new Label();
            txtTitle = new TextBox();
            txtDescription = new TextBox();
            DueDateTimePicker = new DateTimePicker();
            DueDatePicker = new Label();
            PriorityPicker = new Label();
            cmbxPriority = new ComboBox();
            cmbxCategory = new ComboBox();
            CategoryPicker = new Label();
            cmbxStatus = new ComboBox();
            StatusPicker = new Label();
            btnSave = new Button();
            btnCancel = new Button();
            label1 = new Label();
            icnAdd = new FontAwesome.Sharp.IconButton();
            SuspendLayout();
            // 
            // TaskTitle
            // 
            TaskTitle.AutoSize = true;
            TaskTitle.Font = new Font("Segoe UI", 11F);
            TaskTitle.Location = new Point(112, 65);
            TaskTitle.Name = "TaskTitle";
            TaskTitle.Size = new Size(88, 25);
            TaskTitle.TabIndex = 0;
            TaskTitle.Text = "Task Title";
            // 
            // TaskDescription
            // 
            TaskDescription.AutoSize = true;
            TaskDescription.Font = new Font("Segoe UI", 11F);
            TaskDescription.Location = new Point(70, 123);
            TaskDescription.Name = "TaskDescription";
            TaskDescription.Size = new Size(148, 25);
            TaskDescription.TabIndex = 1;
            TaskDescription.Text = "Task Description";
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(224, 66);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(403, 27);
            txtTitle.TabIndex = 2;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(224, 110);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(403, 106);
            txtDescription.TabIndex = 3;
            // 
            // DueDateTimePicker
            // 
            DueDateTimePicker.Location = new Point(224, 231);
            DueDateTimePicker.Name = "DueDateTimePicker";
            DueDateTimePicker.Size = new Size(403, 27);
            DueDateTimePicker.TabIndex = 4;
            // 
            // DueDatePicker
            // 
            DueDatePicker.AutoSize = true;
            DueDatePicker.Font = new Font("Segoe UI", 11F);
            DueDatePicker.Location = new Point(109, 231);
            DueDatePicker.Name = "DueDatePicker";
            DueDatePicker.Size = new Size(90, 25);
            DueDatePicker.TabIndex = 5;
            DueDatePicker.Text = "Due Date";
            // 
            // PriorityPicker
            // 
            PriorityPicker.AutoSize = true;
            PriorityPicker.Font = new Font("Segoe UI", 11F);
            PriorityPicker.Location = new Point(112, 286);
            PriorityPicker.Name = "PriorityPicker";
            PriorityPicker.Size = new Size(73, 25);
            PriorityPicker.TabIndex = 6;
            PriorityPicker.Text = "Priority";
            // 
            // cmbxPriority
            // 
            cmbxPriority.FormattingEnabled = true;
            cmbxPriority.Location = new Point(224, 283);
            cmbxPriority.Name = "cmbxPriority";
            cmbxPriority.Size = new Size(403, 28);
            cmbxPriority.TabIndex = 7;
            // 
            // cmbxCategory
            // 
            cmbxCategory.FormattingEnabled = true;
            cmbxCategory.Location = new Point(224, 331);
            cmbxCategory.Name = "cmbxCategory";
            cmbxCategory.Size = new Size(403, 28);
            cmbxCategory.TabIndex = 9;
            // 
            // CategoryPicker
            // 
            CategoryPicker.AutoSize = true;
            CategoryPicker.Font = new Font("Segoe UI", 11F);
            CategoryPicker.Location = new Point(112, 334);
            CategoryPicker.Name = "CategoryPicker";
            CategoryPicker.Size = new Size(88, 25);
            CategoryPicker.TabIndex = 8;
            CategoryPicker.Text = "Category";
            // 
            // cmbxStatus
            // 
            cmbxStatus.FormattingEnabled = true;
            cmbxStatus.Location = new Point(224, 379);
            cmbxStatus.Name = "cmbxStatus";
            cmbxStatus.Size = new Size(403, 28);
            cmbxStatus.TabIndex = 11;
            // 
            // StatusPicker
            // 
            StatusPicker.AutoSize = true;
            StatusPicker.Font = new Font("Segoe UI", 11F);
            StatusPicker.Location = new Point(112, 382);
            StatusPicker.Name = "StatusPicker";
            StatusPicker.Size = new Size(62, 25);
            StatusPicker.TabIndex = 10;
            StatusPicker.Text = "Status";
            // 
            // btnSave
            // 
            btnSave.Image = (Image)resources.GetObject("btnSave.Image");
            btnSave.ImageAlign = ContentAlignment.MiddleLeft;
            btnSave.Location = new Point(224, 440);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(102, 59);
            btnSave.TabIndex = 16;
            btnSave.Text = "Save";
            btnSave.TextAlign = ContentAlignment.MiddleRight;
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Image = (Image)resources.GetObject("btnCancel.Image");
            btnCancel.ImageAlign = ContentAlignment.MiddleLeft;
            btnCancel.Location = new Point(494, 440);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(102, 59);
            btnCancel.TabIndex = 17;
            btnCancel.Text = "Cancel";
            btnCancel.TextAlign = ContentAlignment.MiddleRight;
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(633, 334);
            label1.Name = "label1";
            label1.Size = new Size(0, 20);
            label1.TabIndex = 18;
            // 
            // icnAdd
            // 
            icnAdd.BackColor = Color.Transparent;
            icnAdd.FlatAppearance.BorderSize = 0;
            icnAdd.FlatStyle = FlatStyle.Flat;
            icnAdd.IconChar = FontAwesome.Sharp.IconChar.Add;
            icnAdd.IconColor = Color.LawnGreen;
            icnAdd.IconFont = FontAwesome.Sharp.IconFont.Auto;
            icnAdd.IconSize = 40;
            icnAdd.Location = new Point(639, 331);
            icnAdd.Name = "icnAdd";
            icnAdd.Size = new Size(49, 39);
            icnAdd.TabIndex = 19;
            icnAdd.Text = " ";
            icnAdd.UseVisualStyleBackColor = false;
            icnAdd.Click += icnAdd_Click;
            // 
            // AddEditTaskForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(800, 511);
            Controls.Add(icnAdd);
            Controls.Add(label1);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(cmbxStatus);
            Controls.Add(StatusPicker);
            Controls.Add(cmbxCategory);
            Controls.Add(CategoryPicker);
            Controls.Add(cmbxPriority);
            Controls.Add(PriorityPicker);
            Controls.Add(DueDatePicker);
            Controls.Add(DueDateTimePicker);
            Controls.Add(txtDescription);
            Controls.Add(txtTitle);
            Controls.Add(TaskDescription);
            Controls.Add(TaskTitle);
            Name = "AddEditTaskForm";
            Text = "AddEditTaskForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label TaskTitle;
        private Label TaskDescription;
        private TextBox txtTitle;
        private TextBox txtDescription;
        private DateTimePicker DueDateTimePicker;
        private Label DueDatePicker;
        private Label PriorityPicker;
        private ComboBox cmbxPriority;
        private ComboBox cmbxCategory;
        private Label CategoryPicker;
        private ComboBox cmbxStatus;
        private Label StatusPicker;
        private Button btnSave;
        private Button btnCancel;
        private Label label1;
        private FontAwesome.Sharp.IconButton icnAdd;
    }
}