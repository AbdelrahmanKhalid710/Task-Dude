﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaskManager_.Models;
using TaskManager_.Services;

namespace TaskManager_
{
    public partial class AddEditTaskForm : Form
    {
        private readonly TaskServices _taskServices;
        private readonly CategoryService _categoryService;
        private readonly TaskItem? _taskItem;
        private readonly bool _IsEditMode;
        public TaskItem TaskItem => _taskItem;  // expose it to MainForm



        // Constructor for ADD
        public AddEditTaskForm(TaskServices taskService, CategoryService categoryService)
        {
            InitializeComponent();
            _taskServices = taskService;
            _categoryService = categoryService;
            _taskItem = new TaskItem();
            _IsEditMode = false;

            this.Load += AddEditTaskForm_Load;
        }
        public AddEditTaskForm(TaskServices taskService, CategoryService categoryService, TaskItem task)
        {
            InitializeComponent();
            _taskServices = taskService;
            _categoryService = categoryService;
            _taskItem = task;
            _IsEditMode = true;

            this.Load += AddEditTaskForm_Load;
        }
        private void LoadTaskData()
        {
            txtTitle.Text = _taskItem.Title;
            txtDescription.Text = _taskItem.Description;
            DueDateTimePicker.Value = _taskItem.DueDate;
            cmbxCategory.SelectedItem = _taskItem.Priority;
            cmbxStatus.SelectedItem = _taskItem.Status.ToString();
            cmbxCategory.SelectedValue = _taskItem.CategoryId;
        }
        //public AddEditTaskForm()
        //{
        //    InitializeComponent();
        //}
        private void ApplyTaskToControls()
        {
            txtTitle.Text = _taskItem.Title;
            txtDescription.Text = _taskItem.Description ?? string.Empty;
            DueDateTimePicker.Value = _taskItem.DueDate == default ? DateTime.Today : _taskItem.DueDate;
            cmbxPriority.SelectedItem = _taskItem.Priority.ToString();
            cmbxStatus.SelectedItem = _taskItem.Status.ToString();

            if (_taskItem.CategoryId != 0)
                cmbxCategory.SelectedValue = _taskItem.CategoryId;
        }

        private async void AddEditTaskForm_Load(object sender, EventArgs e)
        {
            // Fill Priority & Status
            cmbxPriority.Items.AddRange(Enum.GetNames(typeof(TaskPriority)));
            cmbxStatus.Items.AddRange(Enum.GetNames(typeof(TaskStatus)));

            // Load categories
            var categories = await _categoryService.GetAllCategoriesAsync();
            cmbxCategory.DataSource = categories;
            cmbxCategory.DisplayMember = "Name";
            cmbxCategory.ValueMember = "Id";

            // Apply data if Edit mode
            if (_IsEditMode && _taskItem != null)
            {
                txtTitle.Text = _taskItem.Title;
                txtDescription.Text = _taskItem.Description;
                DueDateTimePicker.Value = _taskItem.DueDate;

                cmbxPriority.SelectedItem = _taskItem.Priority.ToString();
                cmbxStatus.SelectedItem = _taskItem.Status.ToString();
                cmbxCategory.SelectedValue = _taskItem.CategoryId;
            }
            else
            {
                DueDateTimePicker.MinDate = DateTime.Now;
                DueDateTimePicker.Value = DateTime.Now;
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTitle.Text))
            {
                MessageBox.Show("Please Enter A Title.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (cmbxCategory.SelectedItem == null || cmbxStatus.SelectedItem == null || cmbxCategory.SelectedValue == null)
            {
                MessageBox.Show("Please choose priority, status and category.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _taskItem.Title = txtTitle.Text.Trim();
            _taskItem.Description = txtDescription.Text.Trim();
            _taskItem.DueDate = DueDateTimePicker.Value;
            _taskItem.Priority = Enum.Parse<TaskPriority>(cmbxPriority.SelectedItem.ToString()!);
            _taskItem.Status = Enum.Parse<TaskStatus>(cmbxStatus.SelectedItem.ToString()!);
            _taskItem.CategoryId = Convert.ToInt32(cmbxCategory.SelectedValue);

            // just return the filled object
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private async void icnAdd_Click(object sender, EventArgs e)
        {
            string categoryName = Microsoft.VisualBasic.Interaction.InputBox(
              "Enter new category name:", "Add Category", "");

            if (!string.IsNullOrWhiteSpace(categoryName))
            {
                var newCategory = new Category { Name = categoryName.Trim() };

                try
                {
                    await _categoryService.AddCategoryAsync(newCategory);

                    // Reload categories in ComboBox
                    var categories = await _categoryService.GetAllCategoriesAsync();
                    cmbxCategory.DataSource = categories;
                    cmbxCategory.DisplayMember = "Name";
                    cmbxCategory.ValueMember = "Id";

                    // Select the newly added category automatically
                    cmbxCategory.SelectedValue = newCategory.Id;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to add category: {ex.Message}",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

    }
}
