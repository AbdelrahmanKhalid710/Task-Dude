﻿namespace TaskManager_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            dataGridView1 = new DataGridView();
            TaskTitle = new DataGridViewTextBoxColumn();
            TaskDescription = new DataGridViewTextBoxColumn();
            TaskDueDate = new DataGridViewTextBoxColumn();
            TaskPriority = new DataGridViewTextBoxColumn();
            TaskStatus = new DataGridViewTextBoxColumn();
            Category = new DataGridViewTextBoxColumn();
            cmbxStatus = new ComboBox();
            txtSearch = new TextBox();
            labelStatus = new Label();
            labelSearch = new Label();
            toolTip1 = new ToolTip(components);
            SearchIcon = new PictureBox();
            ResetIcon = new PictureBox();
            icnAdd = new FontAwesome.Sharp.IconButton();
            icnEdit = new FontAwesome.Sharp.IconButton();
            icnDelete = new FontAwesome.Sharp.IconButton();
            icnRefresh = new FontAwesome.Sharp.IconButton();
            icnReport = new FontAwesome.Sharp.IconButton();
            iconMenuItem1 = new FontAwesome.Sharp.IconMenuItem();
            iconMenuItem2 = new FontAwesome.Sharp.IconMenuItem();
            AppTitle = new Label();
            iconNextPage = new FontAwesome.Sharp.IconButton();
            iconPreviousPage = new FontAwesome.Sharp.IconButton();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SearchIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ResetIcon).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { TaskTitle, TaskDescription, TaskDueDate, TaskPriority, TaskStatus, Category });
            dataGridView1.Location = new Point(1, 132);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(952, 361);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            dataGridView1.CellFormatting += dataGridView1_CellFormatting;
            // 
            // TaskTitle
            // 
            TaskTitle.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            TaskTitle.DataPropertyName = "Title";
            TaskTitle.HeaderText = "Title";
            TaskTitle.MinimumWidth = 6;
            TaskTitle.Name = "TaskTitle";
            TaskTitle.ReadOnly = true;
            // 
            // TaskDescription
            // 
            TaskDescription.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            TaskDescription.DataPropertyName = "Description";
            TaskDescription.HeaderText = "Description";
            TaskDescription.MinimumWidth = 6;
            TaskDescription.Name = "TaskDescription";
            TaskDescription.ReadOnly = true;
            // 
            // TaskDueDate
            // 
            TaskDueDate.DataPropertyName = "DueDate";
            dataGridViewCellStyle1.Format = "d";
            TaskDueDate.DefaultCellStyle = dataGridViewCellStyle1;
            TaskDueDate.HeaderText = "Due Date";
            TaskDueDate.MinimumWidth = 6;
            TaskDueDate.Name = "TaskDueDate";
            TaskDueDate.ReadOnly = true;
            TaskDueDate.Width = 120;
            // 
            // TaskPriority
            // 
            TaskPriority.DataPropertyName = "Priority";
            TaskPriority.HeaderText = "Priority";
            TaskPriority.MinimumWidth = 6;
            TaskPriority.Name = "TaskPriority";
            TaskPriority.ReadOnly = true;
            TaskPriority.Width = 120;
            // 
            // TaskStatus
            // 
            TaskStatus.DataPropertyName = "Status";
            TaskStatus.HeaderText = "Status";
            TaskStatus.MinimumWidth = 6;
            TaskStatus.Name = "TaskStatus";
            TaskStatus.ReadOnly = true;
            TaskStatus.Width = 120;
            // 
            // Category
            // 
            Category.DataPropertyName = "CategoryName";
            Category.HeaderText = "Category";
            Category.MinimumWidth = 6;
            Category.Name = "Category";
            Category.ReadOnly = true;
            Category.Width = 150;
            // 
            // cmbxStatus
            // 
            cmbxStatus.FormattingEnabled = true;
            cmbxStatus.Location = new Point(556, 61);
            cmbxStatus.Name = "cmbxStatus";
            cmbxStatus.Size = new Size(243, 28);
            cmbxStatus.TabIndex = 5;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(556, 95);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(291, 27);
            txtSearch.TabIndex = 6;
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Location = new Point(475, 64);
            labelStatus.Name = "labelStatus";
            labelStatus.Padding = new Padding(4);
            labelStatus.Size = new Size(57, 28);
            labelStatus.TabIndex = 8;
            labelStatus.Text = "Status";
            // 
            // labelSearch
            // 
            labelSearch.AutoSize = true;
            labelSearch.Location = new Point(475, 97);
            labelSearch.Name = "labelSearch";
            labelSearch.Padding = new Padding(4);
            labelSearch.Size = new Size(61, 28);
            labelSearch.TabIndex = 11;
            labelSearch.Text = "Search";
            // 
            // SearchIcon
            // 
            SearchIcon.Image = (Image)resources.GetObject("SearchIcon.Image");
            SearchIcon.Location = new Point(853, 89);
            SearchIcon.Name = "SearchIcon";
            SearchIcon.Size = new Size(40, 42);
            SearchIcon.TabIndex = 16;
            SearchIcon.TabStop = false;
            SearchIcon.Click += SearchIcon_Click;
            // 
            // ResetIcon
            // 
            ResetIcon.Image = (Image)resources.GetObject("ResetIcon.Image");
            ResetIcon.Location = new Point(901, 84);
            ResetIcon.Name = "ResetIcon";
            ResetIcon.Size = new Size(40, 42);
            ResetIcon.TabIndex = 17;
            ResetIcon.TabStop = false;
            ResetIcon.Click += ResetIcon_Click;
            // 
            // icnAdd
            // 
            icnAdd.BackColor = Color.Transparent;
            icnAdd.FlatAppearance.BorderSize = 0;
            icnAdd.FlatStyle = FlatStyle.Flat;
            icnAdd.IconChar = FontAwesome.Sharp.IconChar.Add;
            icnAdd.IconColor = Color.LawnGreen;
            icnAdd.IconFont = FontAwesome.Sharp.IconFont.Auto;
            icnAdd.Location = new Point(13, 74);
            icnAdd.Name = "icnAdd";
            icnAdd.Size = new Size(62, 48);
            icnAdd.TabIndex = 18;
            icnAdd.Text = " ";
            icnAdd.UseVisualStyleBackColor = false;
            icnAdd.Click += icnAdd_Click;
            // 
            // icnEdit
            // 
            icnEdit.BackColor = Color.Transparent;
            icnEdit.FlatAppearance.BorderSize = 0;
            icnEdit.FlatStyle = FlatStyle.Flat;
            icnEdit.IconChar = FontAwesome.Sharp.IconChar.Edit;
            icnEdit.IconColor = Color.DarkOrange;
            icnEdit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            icnEdit.Location = new Point(81, 74);
            icnEdit.Name = "icnEdit";
            icnEdit.Size = new Size(76, 52);
            icnEdit.TabIndex = 19;
            icnEdit.UseVisualStyleBackColor = false;
            icnEdit.Click += icnEdit_Click;
            // 
            // icnDelete
            // 
            icnDelete.BackColor = Color.Transparent;
            icnDelete.FlatAppearance.BorderSize = 0;
            icnDelete.FlatStyle = FlatStyle.Flat;
            icnDelete.IconChar = FontAwesome.Sharp.IconChar.DeleteLeft;
            icnDelete.IconColor = Color.Red;
            icnDelete.IconFont = FontAwesome.Sharp.IconFont.Auto;
            icnDelete.Location = new Point(163, 74);
            icnDelete.Name = "icnDelete";
            icnDelete.Size = new Size(68, 51);
            icnDelete.TabIndex = 20;
            icnDelete.UseVisualStyleBackColor = false;
            icnDelete.Click += icnDelete_Click;
            // 
            // icnRefresh
            // 
            icnRefresh.BackColor = Color.Transparent;
            icnRefresh.FlatAppearance.BorderSize = 0;
            icnRefresh.FlatStyle = FlatStyle.Flat;
            icnRefresh.IconChar = FontAwesome.Sharp.IconChar.Refresh;
            icnRefresh.IconColor = Color.RosyBrown;
            icnRefresh.IconFont = FontAwesome.Sharp.IconFont.Auto;
            icnRefresh.Location = new Point(237, 74);
            icnRefresh.Name = "icnRefresh";
            icnRefresh.Size = new Size(89, 51);
            icnRefresh.TabIndex = 21;
            icnRefresh.UseVisualStyleBackColor = false;
            icnRefresh.Click += icnRefresh_Click;
            // 
            // icnReport
            // 
            icnReport.FlatAppearance.BorderSize = 0;
            icnReport.FlatStyle = FlatStyle.Flat;
            icnReport.IconChar = FontAwesome.Sharp.IconChar.ChartSimple;
            icnReport.IconColor = Color.MediumSeaGreen;
            icnReport.IconFont = FontAwesome.Sharp.IconFont.Auto;
            icnReport.Location = new Point(332, 74);
            icnReport.Name = "icnReport";
            icnReport.Size = new Size(59, 51);
            icnReport.TabIndex = 23;
            icnReport.UseVisualStyleBackColor = true;
            icnReport.Click += icnReport_Click;
            // 
            // iconMenuItem1
            // 
            iconMenuItem1.IconChar = FontAwesome.Sharp.IconChar.None;
            iconMenuItem1.IconColor = Color.Black;
            iconMenuItem1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconMenuItem1.Name = "iconMenuItem1";
            iconMenuItem1.Size = new Size(32, 19);
            iconMenuItem1.Text = "iconMenuItem1";
            // 
            // iconMenuItem2
            // 
            iconMenuItem2.IconChar = FontAwesome.Sharp.IconChar.None;
            iconMenuItem2.IconColor = Color.Black;
            iconMenuItem2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconMenuItem2.Name = "iconMenuItem2";
            iconMenuItem2.Size = new Size(32, 19);
            iconMenuItem2.Text = "iconMenuItem2";
            // 
            // AppTitle
            // 
            AppTitle.AutoSize = true;
            AppTitle.BackColor = Color.Transparent;
            AppTitle.Font = new Font("Arial", 24F, FontStyle.Italic);
            AppTitle.ForeColor = Color.Teal;
            AppTitle.Location = new Point(13, 0);
            AppTitle.Name = "AppTitle";
            AppTitle.Size = new Size(206, 45);
            AppTitle.TabIndex = 24;
            AppTitle.Text = "Task Dude";
            // 
            // iconNextPage
            // 
            iconNextPage.FlatAppearance.BorderSize = 0;
            iconNextPage.FlatStyle = FlatStyle.Flat;
            iconNextPage.IconChar = FontAwesome.Sharp.IconChar.AngleDoubleRight;
            iconNextPage.IconColor = Color.Indigo;
            iconNextPage.IconFont = FontAwesome.Sharp.IconFont.Solid;
            iconNextPage.IconSize = 40;
            iconNextPage.Location = new Point(794, 499);
            iconNextPage.Name = "iconNextPage";
            iconNextPage.Size = new Size(99, 34);
            iconNextPage.TabIndex = 25;
            iconNextPage.UseVisualStyleBackColor = true;
            iconNextPage.Click += iconNextPage_Click;
            // 
            // iconPreviousPage
            // 
            iconPreviousPage.FlatAppearance.BorderSize = 0;
            iconPreviousPage.FlatStyle = FlatStyle.Flat;
            iconPreviousPage.IconChar = FontAwesome.Sharp.IconChar.AngleDoubleLeft;
            iconPreviousPage.IconColor = Color.Indigo;
            iconPreviousPage.IconFont = FontAwesome.Sharp.IconFont.Solid;
            iconPreviousPage.IconSize = 40;
            iconPreviousPage.Location = new Point(30, 499);
            iconPreviousPage.Name = "iconPreviousPage";
            iconPreviousPage.Size = new Size(99, 34);
            iconPreviousPage.TabIndex = 26;
            iconPreviousPage.UseVisualStyleBackColor = true;
            iconPreviousPage.Click += iconPreviousPage_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(952, 545);
            Controls.Add(iconPreviousPage);
            Controls.Add(iconNextPage);
            Controls.Add(AppTitle);
            Controls.Add(icnReport);
            Controls.Add(icnRefresh);
            Controls.Add(icnDelete);
            Controls.Add(icnEdit);
            Controls.Add(icnAdd);
            Controls.Add(ResetIcon);
            Controls.Add(SearchIcon);
            Controls.Add(labelSearch);
            Controls.Add(labelStatus);
            Controls.Add(txtSearch);
            Controls.Add(cmbxStatus);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)SearchIcon).EndInit();
            ((System.ComponentModel.ISupportInitialize)ResetIcon).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private ComboBox cmbxStatus;
        private TextBox txtSearch;
        private Label labelStatus;
        private Label labelSearch;
        private ToolTip toolTip1;
        private PictureBox SearchIcon;
        private PictureBox ResetIcon;
        private DataGridViewTextBoxColumn TaskTitle;
        private DataGridViewTextBoxColumn TaskDescription;
        private DataGridViewTextBoxColumn TaskDueDate;
        private DataGridViewTextBoxColumn TaskPriority;
        private DataGridViewTextBoxColumn TaskStatus;
        private DataGridViewTextBoxColumn Category;
        private FontAwesome.Sharp.IconButton icnAdd;
        private FontAwesome.Sharp.IconButton icnEdit;
        private FontAwesome.Sharp.IconButton icnDelete;
        private FontAwesome.Sharp.IconButton icnRefresh;
        private FontAwesome.Sharp.IconButton icnReport;
        private FontAwesome.Sharp.IconMenuItem iconMenuItem1;
        private FontAwesome.Sharp.IconMenuItem iconMenuItem2;
        private Label AppTitle;
        private FontAwesome.Sharp.IconButton iconNextPage;
        private FontAwesome.Sharp.IconButton iconPreviousPage;
    }
}
