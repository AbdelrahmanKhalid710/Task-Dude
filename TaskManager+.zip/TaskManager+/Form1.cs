using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using TaskManager_.AppDbContext;
using TaskManager_.Models;
using TaskManager_.Services;

namespace TaskManager_
{
    public partial class Form1 : Form
    {
        private readonly TaskServices _taskServices;
        private readonly CategoryService _categoryServices;
        private TaskApplicationDbContext dbContext;
        private NotifyIcon notifyIcon;
        private List<TaskItem> allTasks = new();
        private int currentPage = 1;
        private int pageSize = 5;
        private int totalPages = 1;
        private async Task LoadTasks()
        {
            allTasks = await _taskServices.GetAllTasksAsync(); 
            totalPages = (int)Math.Ceiling((double)allTasks.Count / pageSize);
            currentPage = 1;

            DisplayPage();
            dataGridView1.CellFormatting -= dataGridView1_CellFormatting;
            dataGridView1.CellFormatting += dataGridView1_CellFormatting;
        }

        private void DisplayPage()
        {
            if (allTasks == null || allTasks.Count == 0)
            {
                dataGridView1.DataSource = null;
                return;
            }

            var pagedTasks = allTasks
                .Skip((currentPage - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = pagedTasks;
            HighlightOverdueTasks();


        }
        public Form1(TaskServices taskServices, CategoryService categoryService)
        {
            InitializeComponent();
            _taskServices = taskServices;
            _categoryServices = categoryService;
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            await LoadTasks();
            // Load status ComboBox
            cmbxStatus.Items.Clear();
            cmbxStatus.Items.Add("All");
            foreach (var status in Enum.GetValues(typeof(TaskStatus)))
            {
                cmbxStatus.Items.Add(status);
            }
            cmbxStatus.SelectedIndex = 0;
            SetupNotifyIcon();
            CheckDueTasks(await _taskServices.GetAllTasksAsync());
            StyleDataGridView();
            HighlightOverdueTasks();
        }
        private async void SearchIcon_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim().ToLower();
            string statusFilter = cmbxStatus.SelectedItem?.ToString();

            var task = await _taskServices.GetAllTasksAsync();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                task = task.Where(t => t.Title.ToLower().Contains(searchTerm)
                                  || t.Description.ToLower().Contains(searchTerm)).ToList();
            }
            if (!string.IsNullOrEmpty(statusFilter) && statusFilter != "All")
            {
                task = task.Where(t => t.Status.ToString() == statusFilter).ToList();
            }
            dataGridView1.DataSource = task;
        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            icnEdit.Enabled = dataGridView1.CurrentRow != null;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadTasks();
        }
        private void StyleDataGridView()
        {
            //dataGridView1.EnableHeadersVisualStyles = false;
            //dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 144, 255); // DodgerBlue
            //dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            //dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            //dataGridView1.DefaultCellStyle.BackColor = Color.White;
            //dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            //dataGridView1.DefaultCellStyle.Font = new Font("Segoe UI", 9);
            //dataGridView1.DefaultCellStyle.SelectionBackColor = Color.LightSkyBlue;
            //dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;

            //dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 248, 255); // Light blue tint
            //dataGridView1.BorderStyle = BorderStyle.None;
            //dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.RowTemplate.Height = 40; // taller rows
            dataGridView1.DefaultCellStyle.Font = new Font("Segoe UI", 12);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 12, FontStyle.Bold);

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkSlateBlue;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightBlue;
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.Columns["TaskDueDate"].SortMode = DataGridViewColumnSortMode.Automatic;
        }
        private void ResetIcon_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            _ = LoadTasks();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

            if (dataGridView1.Columns[e.ColumnIndex].Name == "TaskPriority")
            {
                if (e.Value != null)
                {
                    var priority = (TaskPriority)e.Value;
                    switch (priority)
                    {
                        case global::TaskPriority.Low:
                            e.CellStyle.BackColor = Color.LightGreen;
                            break;
                        case global::TaskPriority.Medium:
                            e.CellStyle.BackColor = Color.Khaki;
                            break;
                        case global::TaskPriority.High:
                            e.CellStyle.BackColor = Color.LightCoral;
                            break;
                    }
                }
            }
            if (dataGridView1.Columns[e.ColumnIndex].Name == "TaskStatus")
            {
                if (e.Value != null)
                {
                    var priority = (TaskStatus)e.Value;
                    switch (priority)
                    {
                        case global::TaskStatus.Pending:
                            e.CellStyle.BackColor = Color.DimGray;
                            break;
                        case global::TaskStatus.InProgress:
                            e.CellStyle.BackColor = Color.Orange;
                            break;
                        case global::TaskStatus.Completed:
                            e.CellStyle.BackColor = Color.DarkSeaGreen;
                            break;
                    }
                }
            }
        }

        private async void icnAdd_Click(object sender, EventArgs e)
        {
            var addForm = new AddEditTaskForm(_taskServices, _categoryServices);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                await _taskServices.AddTaskAsync(addForm.TaskItem);
                await LoadTasks();
            }
        }

        private async void icnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow?.DataBoundItem is TaskItem selectedTask)
            {
                var editForm = new AddEditTaskForm(_taskServices, _categoryServices, selectedTask);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    await _taskServices.UpdateTaskAsync(editForm.TaskItem);
                    await LoadTasks();
                }
            }
        }

        private async void icnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow?.DataBoundItem is TaskItem selectedTask)
            {
                var confirmResult = MessageBox.Show("Are you sure to delete this task?", "Confirm Delete", MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {
                    await _taskServices.DeleteTaskAsync(selectedTask.Id);
                    await LoadTasks();
                }
            }
        }

        private async void icnRefresh_Click(object sender, EventArgs e)
        {
            await LoadTasks();
        }

        public void HighlightOverdueTasks()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells["TaskDueDate"].Value is DateTime dueDate)
                {
                    if (dueDate < DateTime.Now && row.Cells["TaskStatus"].Value.ToString() != "Completed")
                    {
                        row.DefaultCellStyle.ForeColor = Color.Red;
                        row.DefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Strikeout);
                    }

                }
            }
        }

        private void SetupNotifyIcon()
        {
            notifyIcon = new NotifyIcon
            {
                Icon = SystemIcons.Information,
                Visible = true,
            };
        }
        private void CheckDueTasks(List<TaskItem> tasks)
        {
           var now = DateTime.Now;
            var overdueTasks = tasks
                    .Where(t => t.DueDate < now && t.Status != global::TaskStatus.Completed)
                    .ToList();
            foreach(var task in overdueTasks)   
            {
                notifyIcon.BalloonTipTitle = "Overdue Task Reminder";
                notifyIcon.BalloonTipText = $"Task : '{task.Title}' is overdue!";
                notifyIcon.ShowBalloonTip(6000);
                
            }
            var dueSoonTasks  = tasks
                    .Where(t => t.DueDate >= now && t.DueDate <= now.AddDays(1) && t.Status != global::TaskStatus.Completed)
                    .ToList();
            foreach (var task in dueSoonTasks)
            {
                notifyIcon.BalloonTipTitle = "Upcoming Task Reminder";
                notifyIcon.BalloonTipText = $"Task : '{task.Title}' is due within 24 hours!";
                notifyIcon.ShowBalloonTip(6000);
            }
        }

        private void icnReport_Click(object sender, EventArgs e)
        {
            var reportForm = new ReportForm(_taskServices);
            reportForm.ShowDialog();
        }

        private void iconNextPage_Click(object sender, EventArgs e)
        {
            if (currentPage < totalPages)
            {
                currentPage++;
                DisplayPage();
            }
        }

        private void iconPreviousPage_Click(object sender, EventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--;
                DisplayPage();
            }
        }
    }
}
