﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TaskManager_.Migrations
{
    /// <inheritdoc />
    public partial class Optional : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TaskItems_AppUsers_AppUserId",
                table: "TaskItems");

            migrationBuilder.AlterColumn<int>(
                name: "AppUserId",
                table: "TaskItems",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_TaskItems_AppUsers_AppUserId",
                table: "TaskItems",
                column: "AppUserId",
                principalTable: "AppUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TaskItems_AppUsers_AppUserId",
                table: "TaskItems");

            migrationBuilder.AlterColumn<int>(
                name: "AppUserId",
                table: "TaskItems",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_TaskItems_AppUsers_AppUserId",
                table: "TaskItems",
                column: "AppUserId",
                principalTable: "AppUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
