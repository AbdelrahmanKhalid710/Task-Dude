﻿namespace TaskManager_.Models
{
    public class TaskItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public TaskPriority Priority { get; set; } // Low, Medium, High
        public TaskStatus Status { get; set; } // Pending, In Progress, Completed
        public DateTime? CompletedAt { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // Foreign key to Category
        public int CategoryId { get; set; }
        public Category Category { get; set; }
        // Foreign key to AppUser
        public int? AppUserId { get; set; }
        public AppUser AppUser { get; set; }

        public string CategoryName => Category?.Name ?? "No Category";


    }
}