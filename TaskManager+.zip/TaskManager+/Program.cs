using TaskManager_.AppDbContext;
using TaskManager_.Services;

namespace TaskManager_
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            var dbContext = new TaskApplicationDbContext();
            var taskServices = new TaskServices(dbContext);
            var categoryServices = new CategoryService(dbContext);
            Application.Run(new Form1(taskServices,categoryServices));
        }
    }
}