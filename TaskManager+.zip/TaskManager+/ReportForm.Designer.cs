﻿namespace TaskManager_
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            dataGridView1 = new DataGridView();
            StatusPanel = new Panel();
            AvgCompletionTime = new Guna.UI2.WinForms.Guna2Panel();
            lblAvgComplTimeCounter = new Label();
            iconButton3 = new FontAwesome.Sharp.IconButton();
            lblavgcompletion = new Label();
            inProgrssPanel = new Guna.UI2.WinForms.Guna2Panel();
            lblInProgressCounter = new Label();
            iconButton2 = new FontAwesome.Sharp.IconButton();
            lblInProgress = new Label();
            pendingPanel = new Guna.UI2.WinForms.Guna2Panel();
            lblPendingCounter = new Label();
            iconButton1 = new FontAwesome.Sharp.IconButton();
            lblPending = new Label();
            completedPanel = new Guna.UI2.WinForms.Guna2Panel();
            lblCompletedCounter = new Label();
            completedIcon = new FontAwesome.Sharp.IconButton();
            lblCompleted = new Label();
            icnReport = new FontAwesome.Sharp.IconButton();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            StatusPanel.SuspendLayout();
            AvgCompletionTime.SuspendLayout();
            inProgrssPanel.SuspendLayout();
            pendingPanel.SuspendLayout();
            completedPanel.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Bottom;
            dataGridView1.Location = new Point(0, 301);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1104, 257);
            dataGridView1.TabIndex = 0;
            // 
            // StatusPanel
            // 
            StatusPanel.BackColor = SystemColors.GradientInactiveCaption;
            StatusPanel.Controls.Add(AvgCompletionTime);
            StatusPanel.Controls.Add(inProgrssPanel);
            StatusPanel.Controls.Add(pendingPanel);
            StatusPanel.Controls.Add(completedPanel);
            StatusPanel.Controls.Add(icnReport);
            StatusPanel.Dock = DockStyle.Top;
            StatusPanel.Location = new Point(0, 0);
            StatusPanel.Name = "StatusPanel";
            StatusPanel.Size = new Size(1104, 283);
            StatusPanel.TabIndex = 1;
            // 
            // AvgCompletionTime
            // 
            AvgCompletionTime.BackColor = Color.Transparent;
            AvgCompletionTime.BorderRadius = 40;
            AvgCompletionTime.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            AvgCompletionTime.Controls.Add(lblAvgComplTimeCounter);
            AvgCompletionTime.Controls.Add(iconButton3);
            AvgCompletionTime.Controls.Add(lblavgcompletion);
            AvgCompletionTime.CustomizableEdges = customizableEdges1;
            AvgCompletionTime.FillColor = Color.Linen;
            AvgCompletionTime.Location = new Point(799, 71);
            AvgCompletionTime.Name = "AvgCompletionTime";
            AvgCompletionTime.ShadowDecoration.CustomizableEdges = customizableEdges2;
            AvgCompletionTime.ShadowDecoration.Depth = 5;
            AvgCompletionTime.ShadowDecoration.Enabled = true;
            AvgCompletionTime.Size = new Size(264, 170);
            AvgCompletionTime.TabIndex = 28;
            // 
            // lblAvgComplTimeCounter
            // 
            lblAvgComplTimeCounter.AutoSize = true;
            lblAvgComplTimeCounter.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblAvgComplTimeCounter.Location = new Point(117, 61);
            lblAvgComplTimeCounter.Name = "lblAvgComplTimeCounter";
            lblAvgComplTimeCounter.Size = new Size(0, 28);
            lblAvgComplTimeCounter.TabIndex = 5;
            // 
            // iconButton3
            // 
            iconButton3.FlatAppearance.BorderSize = 0;
            iconButton3.FlatAppearance.MouseDownBackColor = Color.Transparent;
            iconButton3.FlatAppearance.MouseOverBackColor = Color.Transparent;
            iconButton3.FlatStyle = FlatStyle.Flat;
            iconButton3.IconChar = FontAwesome.Sharp.IconChar.Stopwatch;
            iconButton3.IconColor = Color.Tan;
            iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButton3.IconSize = 36;
            iconButton3.Location = new Point(3, 18);
            iconButton3.Name = "iconButton3";
            iconButton3.RightToLeft = RightToLeft.Yes;
            iconButton3.Size = new Size(25, 31);
            iconButton3.TabIndex = 4;
            iconButton3.UseVisualStyleBackColor = true;
            // 
            // lblavgcompletion
            // 
            lblavgcompletion.AutoSize = true;
            lblavgcompletion.Font = new Font("Segoe UI", 11F);
            lblavgcompletion.Location = new Point(31, 19);
            lblavgcompletion.Name = "lblavgcompletion";
            lblavgcompletion.Size = new Size(230, 25);
            lblavgcompletion.TabIndex = 3;
            lblavgcompletion.Text = "Average Completion Time";
            // 
            // inProgrssPanel
            // 
            inProgrssPanel.BackColor = Color.Transparent;
            inProgrssPanel.BorderRadius = 40;
            inProgrssPanel.Controls.Add(lblInProgressCounter);
            inProgrssPanel.Controls.Add(iconButton2);
            inProgrssPanel.Controls.Add(lblInProgress);
            inProgrssPanel.CustomizableEdges = customizableEdges3;
            inProgrssPanel.FillColor = Color.Salmon;
            inProgrssPanel.Location = new Point(511, 71);
            inProgrssPanel.Name = "inProgrssPanel";
            inProgrssPanel.ShadowDecoration.CustomizableEdges = customizableEdges4;
            inProgrssPanel.ShadowDecoration.Depth = 5;
            inProgrssPanel.ShadowDecoration.Enabled = true;
            inProgrssPanel.Size = new Size(229, 170);
            inProgrssPanel.TabIndex = 27;
            // 
            // lblInProgressCounter
            // 
            lblInProgressCounter.AutoSize = true;
            lblInProgressCounter.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblInProgressCounter.Location = new Point(103, 61);
            lblInProgressCounter.Name = "lblInProgressCounter";
            lblInProgressCounter.Size = new Size(0, 28);
            lblInProgressCounter.TabIndex = 4;
            // 
            // iconButton2
            // 
            iconButton2.FlatAppearance.BorderSize = 0;
            iconButton2.FlatAppearance.MouseDownBackColor = Color.Transparent;
            iconButton2.FlatAppearance.MouseOverBackColor = Color.Transparent;
            iconButton2.FlatStyle = FlatStyle.Flat;
            iconButton2.IconChar = FontAwesome.Sharp.IconChar.Spinner;
            iconButton2.IconColor = Color.White;
            iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButton2.IconSize = 36;
            iconButton2.Location = new Point(25, 0);
            iconButton2.Name = "iconButton2";
            iconButton2.Size = new Size(36, 41);
            iconButton2.TabIndex = 3;
            iconButton2.UseVisualStyleBackColor = true;
            // 
            // lblInProgress
            // 
            lblInProgress.AutoSize = true;
            lblInProgress.Font = new Font("Segoe UI", 11F);
            lblInProgress.Location = new Point(58, 6);
            lblInProgress.Name = "lblInProgress";
            lblInProgress.Size = new Size(149, 25);
            lblInProgress.TabIndex = 2;
            lblInProgress.Text = "InProgress Tasks";
            lblInProgress.TextAlign = ContentAlignment.TopCenter;
            // 
            // pendingPanel
            // 
            pendingPanel.BackColor = Color.Transparent;
            pendingPanel.BorderRadius = 40;
            pendingPanel.Controls.Add(lblPendingCounter);
            pendingPanel.Controls.Add(iconButton1);
            pendingPanel.Controls.Add(lblPending);
            pendingPanel.CustomizableEdges = customizableEdges5;
            pendingPanel.FillColor = Color.RosyBrown;
            pendingPanel.Location = new Point(261, 71);
            pendingPanel.Name = "pendingPanel";
            pendingPanel.ShadowDecoration.CustomizableEdges = customizableEdges6;
            pendingPanel.ShadowDecoration.Depth = 5;
            pendingPanel.ShadowDecoration.Enabled = true;
            pendingPanel.Size = new Size(229, 170);
            pendingPanel.TabIndex = 26;
            // 
            // lblPendingCounter
            // 
            lblPendingCounter.AutoSize = true;
            lblPendingCounter.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblPendingCounter.Location = new Point(103, 61);
            lblPendingCounter.Name = "lblPendingCounter";
            lblPendingCounter.Size = new Size(0, 28);
            lblPendingCounter.TabIndex = 3;
            // 
            // iconButton1
            // 
            iconButton1.FlatAppearance.BorderSize = 0;
            iconButton1.FlatAppearance.MouseDownBackColor = Color.Transparent;
            iconButton1.FlatAppearance.MouseOverBackColor = Color.Transparent;
            iconButton1.FlatStyle = FlatStyle.Flat;
            iconButton1.IconChar = FontAwesome.Sharp.IconChar.ClockFour;
            iconButton1.IconColor = Color.White;
            iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButton1.IconSize = 36;
            iconButton1.Location = new Point(19, 3);
            iconButton1.Name = "iconButton1";
            iconButton1.Size = new Size(36, 41);
            iconButton1.TabIndex = 2;
            iconButton1.UseVisualStyleBackColor = true;
            // 
            // lblPending
            // 
            lblPending.AutoSize = true;
            lblPending.Font = new Font("Segoe UI Symbol", 11F, FontStyle.Italic);
            lblPending.ForeColor = Color.Black;
            lblPending.Location = new Point(61, 9);
            lblPending.Name = "lblPending";
            lblPending.RightToLeft = RightToLeft.No;
            lblPending.Size = new Size(132, 25);
            lblPending.TabIndex = 1;
            lblPending.Text = "Pending Tasks";
            // 
            // completedPanel
            // 
            completedPanel.BackColor = Color.Transparent;
            completedPanel.BorderRadius = 40;
            completedPanel.Controls.Add(lblCompletedCounter);
            completedPanel.Controls.Add(completedIcon);
            completedPanel.Controls.Add(lblCompleted);
            completedPanel.CustomizableEdges = customizableEdges7;
            completedPanel.FillColor = Color.DarkSeaGreen;
            completedPanel.Location = new Point(12, 71);
            completedPanel.Name = "completedPanel";
            completedPanel.ShadowDecoration.CustomizableEdges = customizableEdges8;
            completedPanel.ShadowDecoration.Depth = 5;
            completedPanel.ShadowDecoration.Enabled = true;
            completedPanel.Size = new Size(229, 170);
            completedPanel.TabIndex = 25;
            // 
            // lblCompletedCounter
            // 
            lblCompletedCounter.AutoSize = true;
            lblCompletedCounter.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblCompletedCounter.Location = new Point(86, 61);
            lblCompletedCounter.Name = "lblCompletedCounter";
            lblCompletedCounter.Size = new Size(0, 28);
            lblCompletedCounter.TabIndex = 2;
            // 
            // completedIcon
            // 
            completedIcon.FlatAppearance.BorderSize = 0;
            completedIcon.FlatAppearance.MouseDownBackColor = Color.Transparent;
            completedIcon.FlatAppearance.MouseOverBackColor = Color.Transparent;
            completedIcon.FlatStyle = FlatStyle.Flat;
            completedIcon.IconChar = FontAwesome.Sharp.IconChar.CheckCircle;
            completedIcon.IconColor = Color.White;
            completedIcon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            completedIcon.IconSize = 36;
            completedIcon.Location = new Point(16, 0);
            completedIcon.Name = "completedIcon";
            completedIcon.Size = new Size(36, 41);
            completedIcon.TabIndex = 1;
            completedIcon.UseVisualStyleBackColor = true;
            // 
            // lblCompleted
            // 
            lblCompleted.AutoSize = true;
            lblCompleted.Font = new Font("Segoe UI Symbol", 11F, FontStyle.Italic);
            lblCompleted.ForeColor = Color.Black;
            lblCompleted.Location = new Point(45, 6);
            lblCompleted.Name = "lblCompleted";
            lblCompleted.Size = new Size(154, 25);
            lblCompleted.TabIndex = 0;
            lblCompleted.Text = "Completed Tasks";
            lblCompleted.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // icnReport
            // 
            icnReport.BackColor = Color.Transparent;
            icnReport.Dock = DockStyle.Top;
            icnReport.FlatAppearance.BorderSize = 0;
            icnReport.FlatAppearance.MouseDownBackColor = Color.Transparent;
            icnReport.FlatAppearance.MouseOverBackColor = Color.Transparent;
            icnReport.FlatStyle = FlatStyle.Flat;
            icnReport.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            icnReport.IconChar = FontAwesome.Sharp.IconChar.ChartSimple;
            icnReport.IconColor = Color.MediumSeaGreen;
            icnReport.IconFont = FontAwesome.Sharp.IconFont.Auto;
            icnReport.ImageAlign = ContentAlignment.MiddleLeft;
            icnReport.Location = new Point(0, 0);
            icnReport.Name = "icnReport";
            icnReport.Padding = new Padding(2);
            icnReport.Size = new Size(1104, 51);
            icnReport.TabIndex = 24;
            icnReport.Text = "Task Report";
            icnReport.UseVisualStyleBackColor = false;
            // 
            // ReportForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1104, 558);
            Controls.Add(StatusPanel);
            Controls.Add(dataGridView1);
            Name = "ReportForm";
            Text = "ReportForm";
            Load += ReportForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            StatusPanel.ResumeLayout(false);
            AvgCompletionTime.ResumeLayout(false);
            AvgCompletionTime.PerformLayout();
            inProgrssPanel.ResumeLayout(false);
            inProgrssPanel.PerformLayout();
            pendingPanel.ResumeLayout(false);
            pendingPanel.PerformLayout();
            completedPanel.ResumeLayout(false);
            completedPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private Panel StatusPanel;
        private Label lblavgcompletion;
        private Label lblInProgress;
        private Label lblPending;
        private FontAwesome.Sharp.IconButton icnReport;
        private Label lblCompleted;
        private Guna.UI2.WinForms.Guna2Panel completedPanel;
        private Guna.UI2.WinForms.Guna2Panel pendingPanel;
        private Guna.UI2.WinForms.Guna2Panel inProgrssPanel;
        private Guna.UI2.WinForms.Guna2Panel AvgCompletionTime;
        private FontAwesome.Sharp.IconButton completedIcon;
        private FontAwesome.Sharp.IconButton iconButton2;
        private FontAwesome.Sharp.IconButton iconButton1;
        private FontAwesome.Sharp.IconButton iconButton3;
        private Label lblCompletedCounter;
        private Label lblPendingCounter;
        private Label lblAvgComplTimeCounter;
        private Label lblInProgressCounter;
    }
}