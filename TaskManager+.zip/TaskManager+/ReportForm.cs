﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Forms;
using TaskManager_.Services;

namespace TaskManager_
{
    public partial class ReportForm : Form
    {
        private readonly TaskServices _taskServices;
        public ReportForm(TaskServices taskServices)
        {
            InitializeComponent();
            _taskServices = taskServices;
        }
        private async void ReportForm_Load(object sender, EventArgs e)
        {
            var tasks = await _taskServices.GetAllTasksAsync();
            int completedTasks = tasks.Count(t => t.Status == global::TaskStatus.Completed);
            int pendingTasks = tasks.Count(t => t.Status == global::TaskStatus.Pending);
            int inProgressTasks = tasks.Count(t => t.Status == global::TaskStatus.InProgress);
            lblCompletedCounter.Text = $"{completedTasks}";
            lblPendingCounter.Text = $"{pendingTasks}";
            lblInProgressCounter.Text = $"{inProgressTasks}";
            var completedTasksList = tasks.Where(t => t.Status == TaskStatus.Completed && t.CompletedAt != null).ToList();

            if (completedTasksList.Any())
            {
                // Use CreatedAt -> CompletedAt
                var avgTime = completedTasksList.Average(t =>
                    (t.CompletedAt.Value - t.CreatedAt).TotalHours);

                lblAvgComplTimeCounter.Text = $"{avgTime:F1} hrs";
            }
            else
            {
                lblAvgComplTimeCounter.Text = "N/A";
            }
            dataGridView1.DataSource = tasks;
        }
    }
}
