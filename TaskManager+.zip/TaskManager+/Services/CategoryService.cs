﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManager_.AppDbContext;
using TaskManager_.Models;

namespace TaskManager_.Services
{
    public class CategoryService
    {
        private readonly TaskApplicationDbContext _dbContext;

        public CategoryService(TaskApplicationDbContext dbContext)
        {
           _dbContext = dbContext;
        }
        // Get All Categories
        public async Task<List<Category>> GetAllCategoriesAsync()
        {
            using var db = new TaskApplicationDbContext();
            return await db.Categories.ToListAsync();
        }

        // Add New Category
        public async Task<Category> AddCategoryAsync(Category newCategory)
        {
            using var db = new TaskApplicationDbContext();
            db.Categories.Add(newCategory);
            await db.SaveChangesAsync();
            return newCategory;
        }

        // Update Existing Category
        public async Task UpdateCategoryAsync(Category updatedCategory)
        {
            using var db = new TaskApplicationDbContext();
            db.Categories.Update(updatedCategory);
            await db.SaveChangesAsync();
        }

        // Delete Category
        public async Task DeleteCategoryAsync(int categoryId)
        {
            using var db = new TaskApplicationDbContext();
            var category = await db.Categories.FindAsync(categoryId);
            if (category != null)
            {
                db.Categories.Remove(category);
                await db.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Category not found");
            }
        }
    }
}
