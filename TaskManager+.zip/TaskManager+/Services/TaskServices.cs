﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManager_.AppDbContext;
using TaskManager_.Models;

namespace TaskManager_.Services
{
   public class TaskServices
    {
        private readonly TaskApplicationDbContext _dbContext;

        public TaskServices(TaskApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<TaskItem?> GetTaskByIdAsync(int taskId)
        {
            using var db = new TaskApplicationDbContext();
            return await db.TaskItems
                           .Include(c => c.Category)
                           .Include(u => u.AppUser)
                           .FirstOrDefaultAsync(t => t.Id == taskId);
        }

        // Get All Tasks
        public async Task<List<TaskItem>> GetAllTasksAsync()
        {
            using var db = new TaskApplicationDbContext();
            return await db.TaskItems
                           .Include(c => c.Category)
                           .Include(u => u.AppUser)
                           .ToListAsync();
        }

        // Add New Task
        public async Task<TaskItem> AddTaskAsync(TaskItem newTask)
        {
            using var db = new TaskApplicationDbContext();
            newTask.CreatedAt = DateTime.Now;
            newTask.AppUserId = 1; // Default user

            db.TaskItems.Add(newTask);
            await db.SaveChangesAsync();
            return newTask;
        }

        // Update Existing Task
        public async Task UpdateTaskAsync(TaskItem updatedTask)
        {

            using var db = new TaskApplicationDbContext();

            var existing = await db.TaskItems.FindAsync(updatedTask.Id);
            if (existing == null)
                throw new Exception("Task not found.");

            // Update fields
            existing.Title = updatedTask.Title;
            existing.Description = updatedTask.Description;
            existing.DueDate = updatedTask.DueDate;
            existing.Priority = updatedTask.Priority;
            existing.Status = updatedTask.Status;
            existing.CategoryId = updatedTask.CategoryId;
            existing.AppUserId = updatedTask.AppUserId;

            // Handle CompletedAt logic
            if (updatedTask.Status == TaskStatus.Completed && existing.CompletedAt == null)
            {
                existing.CompletedAt = DateTime.Now;
            }

            await db.SaveChangesAsync();
        }

        // Delete Task
        public async Task DeleteTaskAsync(int taskId)
        {
            using var db = new TaskApplicationDbContext();
            var task = await db.TaskItems.FindAsync(taskId);
            if (task != null)
            {
                db.TaskItems.Remove(task);
                await db.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Task not found");
            }
        }
    }
}
